[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/9sIlYZrI)
# UASRPLBO2025-C
## Deskripsi:
Buatlah sebuah aplikasi Jackpot yang dapat digunakan untuk memutar (spin) 3 buah label yang menampilkan 3 buah huruf.  3 huruf tersebut akan dirandom oleh sistem dalam waktu tertentu (misalnya 1 detik), kemudian saat berhenti program menampikan 3 huruf yang sudah dirandom.  Jika 3 huruf sama maka akan ditampilkan ”Selamat anda menang mendapat Lucky Jackpot!”, sedangakan jika hanya ada 2 huruf yang sama maka ditampilkan ”Selamat anda mendapat 2 huruf sama”, sedangkan jika tidak ada yang sama maka ”Maaf anda belum beruntung”.  Pengguna dapat mengklik tombol spin berkali-kali.  Aplikasi tersebut akan menampilkan form pertama berupa form login dengan input username dan password.  Username dan password bebas yang penting username dan password harus sama.  Jika berhasil login baru aplikasi jackpot tersebut muncul.  Setiap kali user mengklik tombol spin, maka akan dicatat ke database lognya, yang terdiri dari: username yang digunakan, status yang diperoleh (”Selamat anda menang mendapat Lucky Jackpot!”, ”Selamat anda mendapat 2 huruf sama”, atau ”Maaf anda belum beruntung”), sudah attempt berapa kali, dan waktu klik (datetime) ke dalam basis data SQLITE menggunakan Desain Pattern Singleton.
Penjelasan detail tentang class yang harus dibuat:
1.	Class **User** yang menggambarkan username, password, attempts.  Digunakan untuk menyimpan user login yang juga dicatat ke tabel dalam database.
2.	Class **Game** yang menggambarkan game jackpot dengan field dan method sebagai berikut:
- Atribut: letter1, letter2, letter3 untuk menyimpan hasil random huruf.
- Method: getLetter1 sd 3, spin untuk merandom 3 huruf, dan evaluateResult untuk menampilkan status dari hasil random.
4.	Class **DatabaseMenager** digunakan untuk mengelola databse SQLite dan menggunakan Singleton Pattern dan menyimpan data user setiap kali selesai menekan tombol spin.
5.	Class **LoginController** dan **JackpotController** yang merepresentasikan controller dari form yang dibuat, form Login dan Jackpot.  JackpotController menggunakan class Game di dalamnya.
6.	Class **JackpotApplication** yang merepresentasikan aplikasi untuk dijalankan (main)

Tabel database SQLite dibuat dengan kode: 

<pre>
create table users
(
    username TEXT,
    status   TEXT,
    attempts INTEGER,
    waktu    TEXT
);
</pre>

## Rubrik Penilaian:
- Pembuatan class User	10
- Pembuatan class DatabaseController	15
- Pembuatan class Game	15
- Form Jackpot UI	10
- Form Login UI	10
- Form Jackpot Controller	15
- Form Login Controller	10
- Database	10
- Aplikasi berjalan tanpa error	5
- Bonus jika random huruf label dapat berupa animasi bergerak	10
- Total : 110 (dengan bonus)

