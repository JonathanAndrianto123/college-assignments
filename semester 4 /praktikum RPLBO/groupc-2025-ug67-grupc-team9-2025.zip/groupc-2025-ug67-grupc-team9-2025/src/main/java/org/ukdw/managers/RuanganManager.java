package org.ukdw.managers;

import org.ukdw.data.Ruangan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RuanganManager {
    private final Connection conn;

    public RuanganManager(Connection conn) {
        this.conn = conn;
    }

    // Menambahkan ruangan baru
    public boolean addRuangan(String name, int gedungId) {
        String sql = "INSERT INTO ruangan (name, gedung_id) VALUES (?, ?)";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, gedungId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error saat menambahkan ruangan: " + e.getMessage());
            return false;
        }
    }

    // Menghapus ruangan berdasarkan ID
    public boolean deleteRuangan(int id) {
        String sql = "DELETE FROM ruangan WHERE id = ?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error saat menghapus ruangan: " + e.getMessage());
            return false;
        }
    }

    // Mengedit informasi ruangan berdasarkan ID
    public boolean editRuangan(int id, String name, int gedungId) {
        String sql = "UPDATE ruangan SET name = ?, gedung_id = ? WHERE id = ?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, gedungId);
            stmt.setInt(3, id);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error saat mengedit ruangan: " + e.getMessage());
            return false;
        }
    }

    // Mengambil semua daftar ruangan
    public List<Ruangan> allRuangan() {
        List<Ruangan> ruanganList = new ArrayList<>();
        String sql = "SELECT * FROM ruangan";
        try (Connection connection = DBConnectionManager.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int gedungId = rs.getInt("gedung_id");
                ruanganList.add(new Ruangan(id, name, gedungId));
            }
        } catch (SQLException e) {
            System.err.println("Error saat mengambil daftar ruangan: " + e.getMessage());
        }
        return ruanganList;
    }
}
