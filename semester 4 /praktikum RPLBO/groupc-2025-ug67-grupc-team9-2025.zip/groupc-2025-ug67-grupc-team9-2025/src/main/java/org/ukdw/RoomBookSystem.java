package org.ukdw;

import org.ukdw.data.Gedung;
import org.ukdw.data.Ruangan;
import org.ukdw.managers.DBConnectionManager;
import org.ukdw.managers.GedungManager;
import org.ukdw.managers.PemesananManager;
import org.ukdw.managers.RuanganManager;
import org.ukdw.managers.UserManager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

public class RoomBookSystem {
    private final UserManager userManager;
    private final RuanganManager ruanganManager;
    private final GedungManager gedungManager;
    private final PemesananManager pemesananManager;

     public RoomBookSystem(Connection conn) {
        this.userManager = new UserManager(conn);
        this.ruanganManager = new RuanganManager(conn);
        this.gedungManager = new GedungManager(conn);
        this.pemesananManager = new PemesananManager(conn);
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("=== Sistem Pemesanan Ruangan UKDW ===");
            System.out.println("1. Registrasi User");
            System.out.println("2. Login User");
            System.out.println("3. Lihat Semua Data Ruangan");
            System.out.println("4. Tambah Ruangan");
            System.out.println("5. Edit Ruangan");
            System.out.println("6. Hapus Ruangan");
            System.out.println("7. Lihat Semua Data Gedung");
            System.out.println("8. Tambah Gedung");
            System.out.println("9. Edit Gedung");
            System.out.println("10. Hapus Gedung");
            System.out.println("11. Lihat Semua Pemesanan");
            System.out.println("12. Tambah Pemesanan");
            System.out.println("13. Edit Pemesanan");
            System.out.println("14. Hapus Pemesanan");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice){
                case 1:
                    try {
                        registrasiUser(scanner);
                    } catch (IOException e) {
                        System.out.println("Terjadi kesalahan saat registrasi: " + e.getMessage());
                    }
    break;
                case 2 : loginUser(scanner);
                case 3 : lihatSemuaDataRuangan();
                case 4 : addRuangan(scanner);
                case 5 : editRuangan(scanner);
                case 6 : deleteRuangan(scanner);
                case 7 : lihatSemuaDataGedung();
                case 8 : addGedung(scanner);
                case 9 : editGedung(scanner);
                case 10 : deleteGedung(scanner);
                case 11 : lihatSemuaPemesanan();
                case 12 : addPemesanan(scanner);
                case 13 : editPemesanan(scanner);
                case 14 : deletePemesanan(scanner);
                case 0 : exitApps();
                default : System.out.println("Pilihan tidak valid!");
            }
        }
    }
    
    private void editPemesanan(Scanner scanner) {
        System.out.print("Masukkan email: ");
        int id = scanner.nextInt();
        System.out.print("Masukkan email: ");
        String email = scanner.nextLine();
        System.out.print("Masukkan ID Ruangan: ");
        int ruanganId = scanner.nextInt();
        System.out.print("Masukkan Tanggal Check In: ");
        String checkInDate = scanner.nextLine();
        System.out.print("Masukkan Waktu Check In: ");
        String checkInTime = scanner.nextLine();
        System.out.print("Masukkan Tanggal Check Out: ");
        String checkOutDate = scanner.nextLine();
        System.out.print("Masukkan Waktu Check Out: ");
        String checkOutTime = scanner.nextLine();
        scanner.nextLine();
        
        if (pemesananManager.editPemesanan(id, email, ruanganId, checkInDate, checkInTime, checkOutDate, checkOutTime)) {
            System.out.println("Pemesanan berhasil ditambahkan.");
        } else {
            System.out.println("Gagal menambahkan Pemesanan.");
        }
    }

    public void deletePemesanan(Scanner scanner) {
        System.out.print("Masukkan ID Pemesanan: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        if (pemesananManager.deletePemesanan(id)) {
            System.out.println("Pemesanan berhasil dihapus.");
        } else {
            System.out.println("Pemesanan tidak ditemukan.");
        }
    }

    public void deleteGedung(Scanner scanner) {
        System.out.print("Masukkan ID Gedung: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        if (gedungManager.deleteGedung(id)) {
            System.out.println("Gedung berhasil dihapus.");
        } else {
            System.out.println("Gedung tidak ditemukan.");
        }
    }

    // Register User
    private void registrasiUser(Scanner scanner) throws IOException {
        System.out.print("Masukan Email: ");
        String email = scanner.nextLine();
        System.out.print("Masukan Username: ");
        String username = scanner.nextLine();
        System.out.print("Masukan Password: ");
        String password = scanner.nextLine();
        if (userManager.registerUser(email, username, password)) {
            System.out.println("User berhasil didaftarkan!");
        } else {
            System.out.println("Registrasi gagal!");
        }
    }

    // Login User
    private void loginUser(Scanner scanner) {
        System.out.print("Masukan Username: ");
        String username = scanner.nextLine();
        System.out.print("Masukan Password: ");
        String password = scanner.nextLine();
        if (userManager.authenticateUser(username, password)) {
            System.out.println("Login berhasil!");
        } else {
            System.out.println("Login gagal!");
        }
    }

    private void exitApps() {
        System.out.println("Keluar dari aplikasi. Goodbye!");
        System.exit(0);
    }

    private void lihatSemuaDataRuangan() {
        List<Ruangan> ruanganList = ruanganManager.allRuangan();
        for (Ruangan ruangan : ruanganList) {
            System.out.println(ruangan);
        }
    }

    private void addRuangan(Scanner scanner) {
        System.out.print("Masukkan Nama Ruangan: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan ID Gedung: ");
        int gedungId = scanner.nextInt();
        scanner.nextLine();
        
        if (ruanganManager.addRuangan(name, gedungId)) {
            System.out.println("Ruangan berhasil ditambahkan.");
        } else {
            System.out.println("Gagal menambahkan ruangan.");
        }
    }

    private void editRuangan(Scanner scanner) {
        System.out.print("Masukkan ID Ruangan: ");
        int id = scanner.nextInt();
        System.out.print("Masukkan Nama Ruangan: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan ID Gedung: ");
        int gedungId = scanner.nextInt();
        scanner.nextLine();
        
        if (ruanganManager.editRuangan(id, name, gedungId)) {
            System.out.println("Ruangan berhasil diedit.");
        } else {
            System.out.println("Gagal mengedit ruangan.");
        }
    }

    private void deleteRuangan(Scanner scanner) {
        System.out.print("Masukkan ID Ruangan: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        if (ruanganManager.deleteRuangan(id)) {
            System.out.println("Ruangan berhasil dihapus.");
        } else {
            System.out.println("Ruangan tidak ditemukan.");
        }
    }

    private void lihatSemuaDataGedung() {
        List<Gedung> gedungList = gedungManager.allGedung();
        for (Gedung gedung : gedungList) {
            System.out.println(gedung);
        }
    }

    private void addGedung(Scanner scanner) {
        System.out.print("Masukkan Nama Gedung: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan Alamat: ");
        String alamat = scanner.nextLine();
        
        if (gedungManager.addGedung(name, alamat)) {
            System.out.println("Gedung berhasil ditambahkan.");
        } else {
            System.out.println("Gagal menambahkan gedung.");
        }
    }

    private void editGedung(Scanner scanner) {
        System.out.print("Masukkan ID Gedung: ");
        int id = scanner.nextInt();
        System.out.print("Masukkan Nama Gedung: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan Alamat Gedung: ");
        String alamat = scanner.nextLine();
        scanner.nextLine();
        
        if (gedungManager.editGedung(id, name, alamat)) {
            System.out.println("Gedung berhasil diedit.");
        } else {
            System.out.println("Gagal mengedit gedung.");
        }
    }

    private void addPemesanan(Scanner scanner) {
        System.out.print("Masukkan email: ");
        String email = scanner.nextLine();
        System.out.print("Masukkan ID Ruangan: ");
        int ruanganId = scanner.nextInt();
        System.out.print("Masukkan Tanggal Check In: ");
        String checkInDate = scanner.nextLine();
        System.out.print("Masukkan Waktu Check In: ");
        String checkInTime = scanner.nextLine();
        System.out.print("Masukkan Tanggal Check Out: ");
        String checkOutDate = scanner.nextLine();
        System.out.print("Masukkan Waktu Check Out: ");
        String checkOutTime = scanner.nextLine();
        scanner.nextLine();
        
        if (pemesananManager.addPemesanan(email, ruanganId, checkInDate, checkInTime, checkOutDate, checkOutTime)) {
            System.out.println("Pemesanan berhasil ditambahkan.");
        } else {
            System.out.println("Gagal menambahkan Pemesanan.");
        }
    }

    public void lihatSemuaPemesanan() {
        pemesananManager.allPemesanan();
    }


    public static void main(String[] args) {
        try {
            String url = "jdbc:sqlite:udkwroombook.db";
            Connection conn = DriverManager.getConnection(url);

            // Buat tabel users jika belum ada
            String createTableSQL = "CREATE TABLE IF NOT EXISTS users ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "email TEXT NOT NULL, "
                    + "username TEXT NOT NULL UNIQUE, "
                    + "password TEXT NOT NULL"
                    + ");";
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createTableSQL);
            }

            RoomBookSystem roomBookSystem = new RoomBookSystem(conn);
            roomBookSystem.start();
        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
        }
    }
}