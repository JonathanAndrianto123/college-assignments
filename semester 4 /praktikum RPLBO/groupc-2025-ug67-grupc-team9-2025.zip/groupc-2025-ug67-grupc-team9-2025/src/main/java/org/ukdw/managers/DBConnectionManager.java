package org.ukdw.managers;

import java.sql.*;

public class DBConnectionManager {
    private static final String URL = "jdbc:sqlite:ukdwroombook.db";

    // Establish connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    // Close the connection
    public static void closeConnection(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}