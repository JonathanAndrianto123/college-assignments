package org.ukdw.managers;

import org.ukdw.data.User;
import java.sql.*;
import java.util.ArrayList;

public class UserManager {
    private final Connection conn;

    public UserManager(Connection conn) {
        this.conn = conn;
    }

    public boolean registerUser(String email, String username, String password) {
        String sql = "INSERT INTO users (email, username, password) VALUES (?, ?, ?)";

        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, username);
            stmt.setString(3, password);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error during registration: " + e.getMessage());
        }
        return false;
    }

    public boolean authenticateUser(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error during authentication: " + e.getMessage());
        }
        return false;
    }

    public boolean updateProfile(String newEmail, String username, String newPassword) {
        String sql = "UPDATE users SET email = ?, password = ? WHERE username = ?";

        try (Connection connection = DBConnectionManager.getConnection();
        PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, newEmail);
            stmt.setString(2, newPassword);
            stmt.setString(3, username);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Profil telah diupdate");
            } return true;
        } catch (SQLException e) {
            System.out.println("Error during profile update: " + e.getMessage());
        }
        return false;
    }
}