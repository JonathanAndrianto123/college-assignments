package org.ukdw.managers;

import org.ukdw.data.Gedung;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GedungManager {
    private final Connection conn;

    public GedungManager(Connection conn) {
        this.conn = conn;
    }

    public boolean addGedung(String nama, String alamat) {
        String sql = "INSERT INTO gedung (nama, alamat) VALUES (?, ?)";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nama);
            stmt.setString(2, alamat);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Gedung berhasil ditambahkan.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error saat menambahkan gedung: " + e.getMessage());
        }
        return false;
    }

    public boolean deleteGedung(int id) {
        if (id < 0) {
            System.out.println("ID tidak valid");
            return false;
        }
        String sql = "DELETE FROM gedung WHERE id = ?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Gedung telah terhapus.");
                return true;
            } else {
                System.out.println("Gedung tidak ditemukan.");
            }
        } catch (SQLException e) {
            System.err.println("Error saat menghapus gedung: " + e.getMessage());
        }
        return false;
    }

    public boolean editGedung(int id, String nama, String alamat) {
        String sql = "UPDATE gedung SET nama = ?, alamat = ? WHERE id = ?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nama);
            stmt.setString(2, alamat);
            stmt.setInt(3, id);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Gedung sudah diedit.");
                return true;
            } else {
                System.out.println("Gedung dengan ID " + id + " tidak ditemukan.");
            }
        } catch (SQLException e) {
            System.err.println("Error saat mengedit gedung: " + e.getMessage());
        }
        return false;
    }

    public List<Gedung> allGedung() {
        List<Gedung> gedungList = new ArrayList<>();
        String sql = "SELECT * FROM gedung";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Gedung gedung = new Gedung(rs.getInt("id"), rs.getString("nama"), rs.getString("alamat"));
                gedungList.add(gedung);
            }
        } catch (SQLException e) {
            System.err.println("Error saat mengambil daftar gedung: " + e.getMessage());
        }
        return gedungList;
    }
}
