package org.ukdw.data;

public class Ruangan {
    private int id;
    private String name;
    private int idGedung;

    public Ruangan(int id, String name, int idGedung) {
        this.id = id;
        this.name = name;
        this.idGedung = idGedung;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getIdGedung() {
        return idGedung;
    }

    public void setName(String name) {
        try {
            this.name = name;
        } catch (Exception e) {
            System.out.println("Kesalahan saat mengatur Nama Ruangan: " + e.getMessage());
        }
    }

    public void setId(int id) {
        try {
            this.id = id;
        } catch (Exception e) {
            System.out.println("Kesalahan saat mengatur ID: " + e.getMessage());
        }
    }

    public void setIdGedung(int idGedung) {
        try {
            this.idGedung = idGedung;
        } catch (Exception e) {
            System.out.println("Kesalahan saat mengatur ID Gedung: " + e.getMessage());
        }
    }
}
