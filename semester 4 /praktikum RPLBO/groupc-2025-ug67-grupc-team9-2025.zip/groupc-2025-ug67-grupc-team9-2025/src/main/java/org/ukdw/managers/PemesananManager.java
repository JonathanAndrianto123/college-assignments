package org.ukdw.managers;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.ukdw.data.Pemesanan;
import org.ukdw.data.Ruangan;

public class PemesananManager {
    private final Connection conn;

    public PemesananManager(Connection conn) {
        this.conn = conn;
    }

    public boolean editPemesanan(int id, String userEmail, int idRuangan, String checkInDate, String checkInTime, String checkOutDate, String checkOutTime) {
        String sql = "UPDATE pemesanan SET userEmail=?, idRuangan=?, checkInDate=?, checkInTime=?, checkOutDate=?, checkOutTime=? WHERE id=?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userEmail);
            statement.setInt(2, idRuangan);
            statement.setString(3, checkInDate);
            statement.setString(4, checkInTime);
            statement.setString(5, checkOutDate);
            statement.setString(6, checkOutTime);
            statement.setInt(7, id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Pemesanan sudah diedit.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error saat mengedit pemesanan: " + e.getMessage());
        }
        return false;
    }

    public boolean deletePemesanan(int id) {
        String sql = "DELETE FROM pemesanan WHERE id=?";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Pemesanan sudah dihapus.");
                return true;
            } else {
                System.out.println("Pemesanan dengan ID " + id + " tidak ditemukan.");
            }
        } catch (SQLException e) {
            System.err.println("Error saat menghapus pemesanan: " + e.getMessage());
        }
        return false;
    }

    public boolean addPemesanan(String userEmail, int idRuangan, String checkInDate, String checkInTime, String checkOutDate, String checkOutTime) {
        String sql = "INSERT INTO pemesanan (userEmail, idRuangan, checkInDate, checkInTime, checkOutDate, checkOutTime) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userEmail);
            statement.setInt(2, idRuangan);
            statement.setString(3, checkInDate);
            statement.setString(4, checkInTime);
            statement.setString(5, checkOutDate);
            statement.setString(6, checkOutTime);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Pemesanan berhasil ditambahkan.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error saat menambahkan pemesanan: " + e.getMessage());
        }
        return false;
    }

    public List<Pemesanan> allPemesanan() {
        List<Pemesanan> pemesananList = new ArrayList<>();
        String sql = "SELECT * FROM pemesanan";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String userEmail = rs.getString("userEmail");
                int idRuangan = rs.getInt("idRuangan");
                String checkInDate = rs.getString("checkInDate");
                String checkInTime = rs.getString("checkInTime");
                String checkOutDate = rs.getString("checkOutDate");
                String checkOutTime = rs.getString("checkOutTime");

                pemesananList.add(new Pemesanan(id, userEmail, idRuangan, checkInDate, checkInTime, checkOutDate, checkOutTime));
            }
        } catch (SQLException e) {
            System.err.println("Error saat mengambil daftar pemesanan: " + e.getMessage());
        }
        return pemesananList;
    }
}
