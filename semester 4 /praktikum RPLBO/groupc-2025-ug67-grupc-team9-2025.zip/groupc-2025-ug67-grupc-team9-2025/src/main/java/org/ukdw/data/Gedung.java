package org.ukdw.data;

public class Gedung {
    int id;
    String alamat;
    String nama;

    public Gedung(int id, String alamat, String nama) {
        this.id = id;
        this.alamat = alamat;
        this.nama = nama;
    }

    public int getId() {
        return id;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNama() {
        return nama;
    }
}
