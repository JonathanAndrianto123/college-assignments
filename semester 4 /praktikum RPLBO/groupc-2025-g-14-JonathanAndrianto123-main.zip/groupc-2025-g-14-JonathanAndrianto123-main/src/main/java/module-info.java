module org.ukdw {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires java.desktop;

    exports org.ukdw;
    exports org.ukdw.controller;
    exports org.ukdw.model;
    opens org.ukdw to javafx.fxml;
    opens org.ukdw.model to javafx.fxml;
    opens org.ukdw.controller to javafx.fxml;
    exports org.ukdw.util;
    opens org.ukdw.util to javafx.fxml;
    exports org.ukdw.manager;
    opens org.ukdw.manager to javafx.fxml;
    exports org.ukdw.Repository;
    opens org.ukdw.Repository to javafx.fxml;
}