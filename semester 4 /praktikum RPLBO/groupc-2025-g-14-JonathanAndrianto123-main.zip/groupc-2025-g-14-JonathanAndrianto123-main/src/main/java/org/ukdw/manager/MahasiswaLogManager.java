/**
 * Author: dendy
 * Date:26/05/2025
 * Time:7:54
 * Description:
 */

package org.ukdw.manager;

import org.ukdw.Repository.LogRepository;
import org.ukdw.manager.observers.MahasiswaObserver;
import org.ukdw.model.LogEvent;
import org.ukdw.util.DBConnectionManager;

import java.util.List;

public class MahasiswaLogManager implements <MahasiswaObserver> {
    //LogRepository logRepository;

    public MahasiswaLogManager() {
        //
    }

    @Override
    public void onMahasiswaChanged(String message) {
        //
    }


    public List<LogEvent> getAllLogs() {
        //
    }
}