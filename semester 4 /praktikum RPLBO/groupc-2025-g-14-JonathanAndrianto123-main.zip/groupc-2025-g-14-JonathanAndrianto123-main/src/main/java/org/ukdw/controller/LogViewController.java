/**
 * Author: dendy
 * Date:26/05/2025
 * Time:10:09
 * Description:
 */

package org.ukdw.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.ukdw.manager.MahasiswaLogManager;
import org.ukdw.model.LogEvent;

public class LogViewController {

    @FXML
    private TableView<LogEvent> logTable;
    @FXML
    private TableColumn<LogEvent, Integer> idColumn;
    @FXML
    private TableColumn<LogEvent, String> eventColumn;
    @FXML
    private TableColumn<LogEvent, String> timestampColumn;

    private final MahasiswaLogManager mahasiswaLogManager = new MahasiswaLogManager();

    @FXML
    public void initialize() {

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        eventColumn.setCellValueFactory(new PropertyValueFactory<>("event"));
        timestampColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));

        ObservableList<LogEvent> logList = FXCollections.observableArrayList(mahasiswaLogManager.getAllLogs());
        logTable.setItems(logList);
    }
}
