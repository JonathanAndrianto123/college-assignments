package org.ukdw.Repository;

import java.util.List;

public interface Dao<ObjectType, IdType> {

    ObjectType findById(IdType id);

    List<ObjectType> findAll();

    boolean save(ObjectType objectType);

    boolean update(ObjectType newObjectType);

    boolean delete(ObjectType objectType);
}