/**
 * Author: dendy
 * Date:26/05/2025
 * Time:7:50
 * Description:
 */

package org.ukdw.manager.observers;

public interface MahasiswaObserver {
    //void onMahasiswaChanged(String message);
}
