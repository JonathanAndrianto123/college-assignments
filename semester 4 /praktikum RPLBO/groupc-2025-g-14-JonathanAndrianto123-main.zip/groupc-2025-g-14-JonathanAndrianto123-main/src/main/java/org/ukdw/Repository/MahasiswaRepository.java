/**
 * Author: dendy
 * Date:20/05/2025
 * Time:9:28
 * Description:
 */

package org.ukdw.Repository;

import org.ukdw.model.Mahasiswa;
import org.ukdw.util.DBConnectionManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MahasiswaRepository implements Dao<Mahasiswa, String> {

    Connection connection;

    public MahasiswaRepository(Connection connection) {
        this.connection = connection;
        buatTabelJikaBelumAda();
    }

    // Membuat tabel Mahasiswa jika belum ada
    private void buatTabelJikaBelumAda() {
        String sql = "CREATE TABLE IF NOT EXISTS mahasiswa (" +
                "nim TEXT PRIMARY KEY, " +
                "nama TEXT NOT NULL, " +
                "nilai REAL NOT NULL, " +
                "foto BLOB) ";
        try {
            Statement stmt = this.connection.createStatement();
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Gagal membuat tabel: " + e.getMessage());
        }
    }

    @Override
    public Mahasiswa findById(String id) {
        return null;
    }

    @Override
    public List<Mahasiswa> findAll() {
        ArrayList<Mahasiswa> mhslist = new ArrayList<>();
        String sql = "SELECT * FROM mahasiswa";
        try {
            Statement stmt = this.connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                mhslist.add(new Mahasiswa(
                        rs.getString("nim"),
                        rs.getString("nama"),
                        rs.getDouble("nilai"),
                        rs.getBytes("foto")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Gagal membaca data mahasiswa: " + e.getMessage());
        }
        return mhslist;
    }

    // CREATE: Menambahkan Mahasiswa
    @Override
    public boolean save(Mahasiswa mahasiswa) {
        String sql = "INSERT INTO mahasiswa (nim, nama, nilai, foto) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = this.connection.prepareStatement(sql)) {
            pstmt.setString(1, mahasiswa.getNim());
            pstmt.setString(2, mahasiswa.getNama());
            pstmt.setDouble(3, mahasiswa.getNilai());
            pstmt.setBytes(4, mahasiswa.getFoto());
            pstmt.executeUpdate();
            System.out.println("Mahasiswa berhasil ditambahkan.");
            return true;
        } catch (SQLException e) {
            System.err.println("Gagal menambahkan mahasiswa: " + e.getMessage());
            return false;
        }
    }

    // UPDATE: Memperbarui Data Mahasiswa
    @Override
    public boolean update(Mahasiswa newMahasiswa) {
        String sql = "UPDATE mahasiswa SET nama = ?, nilai = ? , foto = ? WHERE nim = ?";
        try (PreparedStatement pstmt = this.connection.prepareStatement(sql)) {
            pstmt.setString(1, newMahasiswa.getNama());
            pstmt.setDouble(2, newMahasiswa.getNilai());
            pstmt.setBytes(3, newMahasiswa.getFoto());
            pstmt.setString(4, newMahasiswa.getNim());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Data mahasiswa berhasil diperbarui.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Gagal memperbarui data mahasiswa: " + e.getMessage());
        }
        return false;
    }

    // DELETE: Menghapus Mahasiswa
    @Override
    public boolean delete(Mahasiswa mahasiswa) {
        String sql = "DELETE FROM mahasiswa WHERE nim = ?";
        try (PreparedStatement pstmt = this.connection.prepareStatement(sql)) {
            pstmt.setString(1, mahasiswa.getNim());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Mahasiswa dengan NIM " + mahasiswa.getNim() + " telah dihapus.");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Gagal menghapus mahasiswa: " + e.getMessage());
        }
        return false;
    }
}
