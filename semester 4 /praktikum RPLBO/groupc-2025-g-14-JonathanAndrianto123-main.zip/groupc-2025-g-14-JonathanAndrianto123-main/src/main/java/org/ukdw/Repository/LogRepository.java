/**
 * Author: dendy
 * Date:26/05/2025
 * Time:7:58
 * Description:
 */

package org.ukdw.Repository;

import org.ukdw.model.LogEvent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogRepository implements Dao<LogEvent, Integer> {

    Connection connection;

    public LogRepository(Connection connection) {
        //this.connection = connection;
        buatTabelJikaBelumAda();
    }

    // 🆕 Membuat tabel log jika belum ada
    public void buatTabelJikaBelumAda() {
        String sql = """
                    CREATE TABLE IF NOT EXISTS log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        event TEXT NOT NULL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                """;

        try (Statement stmt = this.connection.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Gagal membuat tabel log: " + e.getMessage());
        }
    }

    @Override
    public LogEvent findById(Integer id) {
        return null;
    }

    @Override
    public List<LogEvent> findAll() {
        List<LogEvent> logs = new ArrayList<>();
        //String sql = "SELECT id, event, timestamp FROM log ORDER BY timestamp DESC";

        //

        return logs;
    }

    @Override
    public boolean save(LogEvent logEvent) {
        String sql = "INSERT INTO log (event) VALUES (?)";

        //
        return false;
    }

    @Override
    public boolean update(LogEvent newObjectType) {
        return false;
    }

    @Override
    public boolean delete(LogEvent logEvent) {
        return false;
    }

    // Menghapus semua log
    public void clearLogs() {
        String sql = "DELETE FROM log";
        //
    }
}
