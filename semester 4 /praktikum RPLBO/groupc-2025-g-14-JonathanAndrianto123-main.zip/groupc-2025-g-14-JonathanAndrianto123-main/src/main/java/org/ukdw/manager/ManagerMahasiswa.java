/**
 * Author: dendy
 * Date:11/03/2025
 * Time:10:35
 * Description:
 */

package org.ukdw.manager;

import org.ukdw.Repository.Dao;
import org.ukdw.Repository.MahasiswaRepository;
import org.ukdw.manager.observers.MahasiswaObserver;
import org.ukdw.model.Mahasiswa;
import org.ukdw.util.DBConnectionManager;

import java.util.ArrayList;
import java.util.List;

public class ManagerMahasiswa {

    MahasiswaRepository mahasiswaRepository;
    private final List<MahasiswaObserver> observers = new ArrayList<>();

    public ManagerMahasiswa() {
        mahasiswaRepository = new MahasiswaRepository(DBConnectionManager.getConnection());
    }

    // CREATE: Menambahkan Mahasiswa
    public boolean tambahMahasiswa(Mahasiswa mahasiswa) {
        if (mahasiswaRepository.save(mahasiswa)) {
            //notifyObservers("Mahasiswa ditambahkan: " + mahasiswa.getNama() + " (NIM: " + mahasiswa.getNim() + ")");
            return true;
        } else {
            return false;
        }
    }

    public ArrayList<Mahasiswa> getAllMahasiswa() {
        return (ArrayList<Mahasiswa>) mahasiswaRepository.findAll();
    }

    // UPDATE: Memperbarui Data Mahasiswa
    public boolean updateMahasiswa(Mahasiswa mahasiswa) {
        if (mahasiswaRepository.update(mahasiswa)) {
            //
            return true;
        } else {

            return false;
        }

    }

    // DELETE: Menghapus Mahasiswa
    public boolean hapusMahasiswa(String nim) {
        if (mahasiswaRepository.delete(new Mahasiswa(nim, "", 0, "".getBytes()))) {
            //
            return true;
        } else {

            return false;
        }
    }

    public void addObserver(MahasiswaObserver observer) {
//        observers.add(observer);
    }

    private void notifyObservers(String message) {
//        for (MahasiswaObserver observer : observers) {
//            observer.onMahasiswaChanged(message);
//        }
    }
}
