/**
 * Author: dendy
 * Date:26/05/2025
 * Time:7:59
 * Description:
 */

package org.ukdw.model;

import java.time.LocalDateTime;

public class LogEvent {
    private int id;
    private String event;
    private LocalDateTime timestamp;

    // Konstruktor tanpa parameter (penting untuk ORM/framework tertentu)
    public LogEvent() {}

    // Konstruktor lengkap
    public LogEvent(int id, String event, LocalDateTime timestamp) {

    }

    // Konstruktor tanpa ID (untuk insert baru)
    public LogEvent(String event) {

    }

    // Getter dan Setter

    @Override
    public String toString() {
        //return "[" + timestamp + "] " + event;
    }
}
