[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/kE8quiEU)
# Booking Ruangan UKDW MiniProject
A solution for Sistem Booking Ruangan UKDW mini project
Sistem Manajemen Kehadiran Siswa adalah sistem untuk membantu sekolah mengelola catatan kehadiran mereka secara efisien. Sistem ini menyediakan antarmuka sederhana dengan menggunakan console untuk navigasi menu dan interaksi. Sistem ini menggunakan SQLite sebagai database  untuk menyimpan org.kehadiransiswa.data kehadiran dengan aman. 
Sistem ini menekankan prinsip-prinsip Pemrograman Berorientasi Objek (OOP) 
untuk memastikan modularitas kode, reuseability, dan pemeliharaan. Sistem ini awalnya dibuat berbasis
console, tugas Team Anda adalah membuat GUI untuk aplikasi ini.

## Requirement
Pengerjaan terbagi menjadi 2 tahap. Untuk detail requirement dan fitur yang dikerjakan silahkan merujuk pada Tugas di Eclass.

## Desain
Berikut adalah desain class diagram aplikasi yang akan dibuat.
![plot](/docs/classDiagram.png)