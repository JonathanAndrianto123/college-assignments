package org.ukdw.view;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import org.ukdw.data.Pemesanan;
import org.ukdw.data.Ruangan;
import org.ukdw.managers.PemesananManager;
import org.ukdw.managers.RuanganManager;
import org.ukdw.utils.DBConnectionManager;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;

public class PemesananView implements Initializable {

    @FXML
    private Button btnUbah;
    @FXML
    private ChoiceBox<Ruangan> ruanganChoiceBox;
    @FXML
    private TextField emailField;
    @FXML
    private DatePicker tanggalCheckInPicker;
    @FXML
    private DatePicker tanggalCheckOutPicker;

    @FXML
    private TextField jamCheckInField;

    @FXML
    private TextField jamCheckOutField;
    @FXML
    private TextField searchBox;

    @FXML
    private TableView<Pemesanan> table;
    @FXML
    private TableColumn<Pemesanan, String> colId;
    @FXML
    private TableColumn<Pemesanan, String> colIdStudent;
    @FXML
    private TableColumn<Pemesanan, String> colIdKelas;
    @FXML
    private TableColumn<Pemesanan, String> colIdKelas1;

    private final ObservableList<Pemesanan> data = FXCollections.observableArrayList();

    Connection connection = DBConnectionManager.getConnection();
    PemesananManager pemesananManager = new PemesananManager(connection);
    RuanganManager ruanganManager = new RuanganManager(connection);


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));
        colIdStudent.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getUserEmail()));
        colIdKelas.setCellValueFactory(cellData -> {
            int idRuangan = cellData.getValue().getIdRuangan();
            String namaRuangan = ruanganManager.getRuanganNameById(idRuangan);
            return new SimpleStringProperty(namaRuangan);
        });
        colIdKelas1.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCheckInDate()));

        data.addAll(pemesananManager.getAllPemesanan());
        table.setItems(data);

        RuanganManager ruanganManager = new RuanganManager(connection);
        ObservableList<Ruangan> daftarRuangan = FXCollections.observableArrayList(ruanganManager.getAllRuangan());
        ruanganChoiceBox.setItems(daftarRuangan);

        ruanganChoiceBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(Ruangan ruangan) {
                return ruangan != null ? ruangan.getName() : "";
            }

            @Override
            public Ruangan fromString(String s) {
                return null;
            }
        });


    }

    public void handleClearSearchText(ActionEvent actionEvent) {
        searchBox.clear();
        table.setItems(data);
    }

    public void handleAddAction(ActionEvent actionEvent) {
        String email = emailField.getText();
        Ruangan selectedRuangan = ruanganChoiceBox.getValue();
        String checkIn = String.valueOf(tanggalCheckInPicker.getValue());
        String jamIn = jamCheckInField.getText();
        String jamOut = jamCheckOutField.getText();
        String checkOut = String.valueOf(tanggalCheckOutPicker.getValue());

        if (email.isEmpty() || selectedRuangan == null || checkIn == null || jamIn.isEmpty() || checkOut == null || jamOut.isEmpty()) {
            showAlert("Input Tidak Lengkap", "Silakan isi semua data pemesanan.");
            return;
        }

        if (!emailFormat(email)) {
            showAlert("Email tidak Valid", "Silahkan isi email yang valid");
        }

        if (!jamFormat(jamIn) || !jamFormat(jamOut)) {
            showAlert(" Format Jam Salah", "Jam harus dalam format 24 jam, misalnya 14:00.");
        }

        int ruangan = selectedRuangan.getId();

        boolean success = pemesananManager.addPemesanan(email, ruangan, checkIn, checkOut, jamIn, jamOut);
        if (success) {
            data.clear();
            data.addAll(pemesananManager.getAllPemesanan());
        }
    }

    public void handleBatalAction(ActionEvent actionEvent) {
        emailField.clear();
        ruanganChoiceBox.getSelectionModel().clearSelection();
        tanggalCheckInPicker.setValue(null);
        jamCheckInField.clear();
        tanggalCheckOutPicker.setValue(null);
        jamCheckOutField.clear();
    }

    public void handleEditAction(ActionEvent actionEvent) {
        Pemesanan selected = table.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Tidak ada data dipilih", "Pilih data pemesanan yang ingin diubah.");
            return;
        }

        emailField.setText(selected.getUserEmail());
        tanggalCheckInPicker.setValue(LocalDate.parse(selected.getCheckInDate()));
        tanggalCheckOutPicker.setValue(LocalDate.parse(selected.getCheckOutDate()));
        jamCheckInField.setText(selected.getCheckInTime());
        jamCheckOutField.setText(selected.getCheckOutTime());
        for (Ruangan r : ruanganChoiceBox.getItems()) {
            if (r.getId() == selected.getIdRuangan()) {
                ruanganChoiceBox.setValue(r);
                break;
            }
        }

        String email = emailField.getText();
        Ruangan selectedRuangan = ruanganChoiceBox.getValue();
        String checkIn = String.valueOf(tanggalCheckInPicker.getValue());
        String jamIn = jamCheckInField.getText();
        String checkOut = String.valueOf(tanggalCheckOutPicker.getValue());
        String jamOut = jamCheckOutField.getText();

        if (email.isEmpty() || selectedRuangan == null || checkIn == null || jamIn.isEmpty() || checkOut == null || jamOut.isEmpty()) {
            showAlert("Input Tidak Lengkap", "Silakan isi semua data pemesanan.");
            return;
        }

        if (!emailFormat(email)) {
            showAlert("Email tidak Valid", "Silahkan isi email yang valid");
        }

        if (!jamFormat(jamIn) || !jamFormat(jamOut)) {
            showAlert(" Format Jam Salah", "Jam harus dalam format 24 jam, misalnya 14:00.");
        }

        int ruangan = selectedRuangan.getId();

        boolean success = pemesananManager.editPemesanan(selected.getId(), email, ruangan, checkIn, checkOut, jamIn, jamOut);
        if (success) {
            data.clear();
            data.addAll(pemesananManager.getAllPemesanan());
        }
    }

    private void showAlert(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.show();
    }

    private boolean emailFormat(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    private boolean jamFormat(String time) {
        return time.matches("^([01]\\d|2[0-3]):[0-5]\\d$");
    }

    private void filterData(String keyword) {
        if (keyword == null || keyword.isEmpty()) {
            table.setItems(data);
            return;
        }

        ObservableList<Pemesanan> filteredList = FXCollections.observableArrayList();

        for (Pemesanan p : data) {
            String email = p.getUserEmail().toLowerCase();
            String namaRuangan = ruanganManager.getRuanganNameById(p.getIdRuangan()).toLowerCase();

            if (email.contains(keyword.toLowerCase()) || namaRuangan.contains(keyword.toLowerCase())) {
                filteredList.add(p);
            }
        }

        table.setItems(filteredList);
    }

    @FXML
    public void handleSearchKeyReleased() {
        String keyword = searchBox.getText();
        filterData(keyword);
    }

    @FXML
    private void handleLaporanAction(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/org/ukdw/laporan-pemesanan-view.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Data Gedung");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
