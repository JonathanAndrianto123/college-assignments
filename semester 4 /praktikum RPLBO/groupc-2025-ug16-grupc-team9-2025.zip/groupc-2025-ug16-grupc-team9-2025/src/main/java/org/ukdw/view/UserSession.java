package org.ukdw.view;

import org.ukdw.data.User;
import org.ukdw.managers.UserManager;
import org.ukdw.utils.DBConnectionManager;

import java.sql.Connection;
import java.util.prefs.Preferences;

public class UserSession {
    private static User currentUser;
    private static final Preferences prefs = Preferences.userNodeForPackage(UserSession.class);

    public static void setCurrentUser(User user) {
        currentUser = user;
        prefs.put("loggedInUser", user.getUsername());
    }

    public static User getCurrentUser() {
        if (currentUser == null) {
            String username = prefs.get("loggedInUser", null);
            if (username != null) {
                try {
                    Connection conn = DBConnectionManager.getConnection();
                    UserManager userManager = new UserManager(conn);
                    currentUser = userManager.getUserByUsername(username); // Buat method ini
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return currentUser;
    }


    public static boolean isLoggedIn() {
        return getCurrentUser() != null;
    }

    public static void logout() {
        currentUser = null;
        prefs.remove("loggedInUser");
    }
}

