package org.ukdw;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.ukdw.utils.DBConnectionManager;
import org.ukdw.view.UserSession;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        DBConnectionManager.createTables();

        if (UserSession.isLoggedIn()) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/ukdw/main-view.fxml"));
            primaryStage.setTitle("Main - UKDW Room Book");
            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
            primaryStage.show();
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/ukdw/login-view.fxml"));
            primaryStage.setTitle("Login - UKDW Room Book");
            Scene scene = new Scene(loader.load());
            primaryStage.setScene(scene);
            primaryStage.show();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
