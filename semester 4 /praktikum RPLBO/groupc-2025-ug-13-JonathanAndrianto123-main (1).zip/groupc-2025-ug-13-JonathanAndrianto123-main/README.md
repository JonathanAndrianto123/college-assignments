[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/h3GztqFJ)
# UG13_A_2024
Modifikasi program daftar catatan sederhana ini agar menggunakan pola desain berikut:

## Kebutuhan Non-fungsional
- Refactor mekanisme akses database agar menggunakan pola desain Data Access Object. 
- Refactor mekanisme pemberian obyek Driver database dengan menggunakan pola desain Dependency Injection
  agar kedepannya aplikasi mudah berganti Drive database dengan yang lain