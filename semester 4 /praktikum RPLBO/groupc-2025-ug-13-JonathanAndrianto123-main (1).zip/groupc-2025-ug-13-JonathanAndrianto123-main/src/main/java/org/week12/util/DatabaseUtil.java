package org.week12.util;

import org.week12.data.Catatan;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {
    private final String DB_URL = "jdbc:sqlite:catatanku.db";
    private Connection connection;

    private static volatile DatabaseUtil instance = null;

    private DatabaseUtil() {
    }

    public static DatabaseUtil getInstance() {
        if (instance == null) {
            // To make thread safe
            synchronized (DatabaseUtil.class) {
                // check again as multiple threads
                // can reach above step
                if (instance == null) {
                    instance = new DatabaseUtil();
                    instance.getConnection();
                    instance.createTable();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(DB_URL);
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle database connection error
            }
        }
        return connection;
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle database connection closure error
            }
        }
    }

    /* Create database tables if they don't exist
     * */
    public void createTable() {
        String mhsTableSql = "CREATE TABLE IF NOT EXISTS catatan ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "judul TEXT NOT NULL,"
                + "konten TEXT NOT NULL,"
                + "kategori TEXT NOT NULL"
                + ")";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(mhsTableSql);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle table creation error
        }
    }


    public List<Catatan> getAllDataCatatan() {
        String query = "SELECT * FROM catatan";
        List<Catatan> catatanList = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String judul = resultSet.getString("judul");
                String konten = resultSet.getString("konten");
                String kategori = resultSet.getString("kategori");
                Catatan catatan = new Catatan(id, judul, konten, kategori);
                catatanList.add(catatan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database query error
        }
        return catatanList;
    }

    public boolean deleteCatatan(Catatan catatan) {
        String query = "DELETE FROM catatan WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, catatan.getId());
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean addCatatan(Catatan catatan) {
        String queryGetNextId = "SELECT seq FROM SQLITE_SEQUENCE WHERE name = 'catatan' LIMIT 1";
        String queryInsert = "INSERT INTO catatan (judul, konten, kategori) VALUES (?, ?, ?)";
        try {
            connection.setAutoCommit(false); // Start transaction
            try (PreparedStatement getNextIdStatement = connection.prepareStatement(queryGetNextId);
                 PreparedStatement insertStatement = connection.prepareStatement(queryInsert)) {
                // Execute query to get the next ID
                ResultSet resultSet = getNextIdStatement.executeQuery();
                int nextId = 1; // Default value if no rows are returned
                if (resultSet.next()) {
                    nextId = resultSet.getInt("seq") + 1;
                }
                // Set parameters for insert query
                insertStatement.setString(1, catatan.getJudul());
                insertStatement.setString(2, catatan.getKonten());
                insertStatement.setString(3, catatan.getKategori());
                // Execute insert query
                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {
                    catatan.setId(nextId);
                    connection.commit(); // Commit transaction
                    return true;
                }
            } catch (SQLException e) {
                connection.rollback(); // Rollback transaction
                e.printStackTrace();
                // Handle database query error
            } finally {
                connection.setAutoCommit(true); // Reset auto-commit mode
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateCatatan(Catatan oldCatatan, Catatan newCatatan) {
        String query = "UPDATE catatan SET judul = ?, konten = ?,  kategori = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, newCatatan.getJudul());
            preparedStatement.setString(2, newCatatan.getKonten());
            preparedStatement.setString(3, newCatatan.getKategori());
            preparedStatement.setInt(4, oldCatatan.getId());
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database query error
        }
        return false;
    }
}
